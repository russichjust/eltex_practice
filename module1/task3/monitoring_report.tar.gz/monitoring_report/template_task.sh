#!/bin/bash

SCRIPT_NAME=$(basename "$0")

if [ "$SCRIPT_NAME"="template_task.sh" ]; then
	echo "Я бригадир, сам не работаю"
	exit 1
fi

REPORT_FILE="report_${SCRIPT_NAME}.log"

PID=$$
echo "[$PID] $(date '+%Y-%m-%d %H:%M:%S') Скрипт запущен" >> "$REPORT_FILE"

RANDOM_SEC=$((RANDOM % 1771 + 30))
sleep $RANDOM_SEC

MIN=$(((RANDOM_SEC + 59)/60))
echo "[$PID] $(date '+%Y-%m-%d %H:%M:%S') Скрипт завершился, работал $MIN минут" >> "$REPORT_FILE"
