#!/bin/bash

CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"

log_msg() {
	echo "[$(date '+%Y-%m-%d %H:%M:%S') $1]" >> "$LOG_FILE"
}

if [ ! -f "$CONFIG_FILE" ]; then
	log_msg "Error. Файл конфигурации $CONFIG_FILE не найден"
	exit 1
fi

while IFS= read -r script || [ -n "$script" ]; do
	if [[ -z "$script" || "$script" =~ ^[[:space:]]*# ]]; then
		continue
	fi
	script=$(echo "$script" | xargs)
	script_basename=$(basename "$script")
	running=false
	for proc_dir in /proc/[0-9]*; do
		if [ -d "$proc_dir" ]; then
			if [ -r "$proc_dir/cmdline" ]; then
				cmdline=$(tr '\0' ' ' < "$proc_dir/cmdline")
				if [[ "$cmdline" == *"$script_basename"* ]]; then
					running=true
					break
				fi
			fi
		fi
	done

	if ! $running; then
		if [ ! -f "$script" ]; then
			log_msg "Скрипт $script не найден, пропуск"
			continue
		fi

		if [ ! -x "$script" ]; then
			chmod +x "$script"
		fi

		#скрипт в отключенном от терминала режиме
		nohup "./$script" > /dev/null 2>&1 &
		log_msg "Скрипт $script_basename [PID: $!] запущен"
	else
		log_msg "Скрипт $script_basename уже был запущен"
	fi
done < "$CONFIG_FILE"
log_msg "Проверка завершена"

